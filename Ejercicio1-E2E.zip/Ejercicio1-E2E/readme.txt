README – Ejercicio Práctico QA  
Automatización End-to-End (E2E) – DemoBlaze  
=========================================================

Este paquete contiene la solución al Ejercicio 1 del examen práctico de QA,
correspondiente a la automatización del flujo E2E en la página:

    https://www.demoblaze.com/

El objetivo de esta automatización es validar el flujo completo de compra:
1. Selección de dos productos.
2. Agregar productos al carrito.
3. Visualización del carrito.
4. Inicio del proceso de compra.
5. Completar el formulario de “Place Order”.
6. Finalizar la compra exitosamente.

El proyecto fue implementado utilizando:
✔ Serenity BDD  
✔ Java  
✔ Cucumber (BDD)  
✔ Patrón Screenplay / Page Object  

---------------------------------------------------------
REQUISITOS PREVIOS
---------------------------------------------------------

Para ejecutar los tests, debe asegurarse de contar con:

• Java JDK 11 o superior  
• Apache Maven 3.8+  
• Sistema operativo Windows / Linux / Mac  
• Conexión a internet  
• Navegador Google Chrome  
• Opcional: Un IDE como IntelliJ IDEA o Eclipse  

---------------------------------------------------------
INSTRUCCIONES DE EJECUCIÓN
---------------------------------------------------------

1. Descargue y descomprima el archivo .zip del proyecto.  
2. Abra una terminal dentro de la carpeta raíz donde se encuentra el archivo:

       pom.xml

3. Ejecute el siguiente comando para limpiar, compilar y ejecutar las pruebas:

       mvn clean verify

4. Serenity generará automáticamente los reportes HTML al finalizar la ejecución.

---------------------------------------------------------
UBICACIÓN DE LOS REPORTES
---------------------------------------------------------

Los reportes se encuentran en la ruta:

       target/site/serenity/index.html

El reporte incluye:
• Capturas de pantalla automáticas  
• Trazabilidad paso a paso (Given–When–Then)  
• Estados de cada step (SUCCESS / FAILURE / PENDING)  
• Gráficos de rendimiento  
• Estadísticas por escenario, por requerimiento y por feature  

---------------------------------------------------------
ESTRUCTURA DEL PROYECTO
---------------------------------------------------------

/src/test/java
    ├── models/           → Modelos y datos utilizados en la prueba
    ├── tasks/            → Acciones reutilizables (Screenplay)
    ├── userinterface/    → Page Objects con mapeos de elementos
    ├── stepdefinitions/  → Pasos de Cucumber
    └── runners/          → Runner SerenityJUnit

/src/test/resources
    └── features/         → Archivos .feature (BDD)

/target/site/serenity     → Reportes generados automáticamente

---------------------------------------------------------
FLUJO AUTOMATIZADO (DETALLADO)
---------------------------------------------------------

El escenario completo automatiza el proceso:

1. Abrir el sitio DemoBlaze.
2. Seleccionar el producto 1 (ej. Samsung S6).
3. Agregar el producto al carrito.
4. Retornar al catálogo.
5. Seleccionar el producto 2.
6. Agregarlo al carrito.
7. Abrir el carrito desde la barra de navegación.
8. Validar que los productos agregados aparezcan en la tabla.
9. Completar el formulario de compra:
      - Nombre
      - País
      - Ciudad
      - Número de tarjeta
      - Mes y Año
10. Confirmar la transacción.
11. Validar que se muestre el mensaje de compra exitosa con ID generado.

