E2E Serenity - Demoblaze

Requisitos:
- JDK 17
- Maven 3.8+
- Google Chrome instalado

Ejecución (desde consola):
1) Ir a la carpeta del proyecto:
   cd C:\ESPE\QA\qa-examen\e2e-serenity

2) Ejecutar pruebas y generar reporte Serenity:
   mvn clean verify

3) Reporte Serenity:
   target\site\serenity\index.html

4) Evidencia Cucumber JSON:
   target\cucumber\cucumber.json

Notas:
- El driver de Chrome se descarga automáticamente (webdriver.autodownload=true).
- Si desea que Chrome no se cierre al terminar, revisar serenity.properties:
  serenity.keep.browser.open=true

