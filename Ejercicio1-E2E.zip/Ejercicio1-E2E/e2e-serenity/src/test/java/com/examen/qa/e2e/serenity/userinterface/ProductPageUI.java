package com.examen.qa.e2e.serenity.userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class ProductPageUI {

    public static final Target ADD_TO_CART =
            Target.the("Boton Add to cart")
                    .locatedBy("//a[contains(.,'Add to cart')]");
}
