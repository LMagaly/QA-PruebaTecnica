package com.examen.qa.e2e.serenity.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.Tasks;

public class AbrirLaPagina implements Task {

    public static AbrirLaPagina demoblaze() {
        return Tasks.instrumented(AbrirLaPagina.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Open.url("https://www.demoblaze.com/")
        );
    }
}
