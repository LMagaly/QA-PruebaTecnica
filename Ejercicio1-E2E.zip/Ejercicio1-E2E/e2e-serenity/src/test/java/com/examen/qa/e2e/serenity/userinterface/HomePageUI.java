package com.examen.qa.e2e.serenity.userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class HomePageUI {

    // Menú Home (a veces sirve, pero NO dependas solo de esto)
    public static final Target HOME_MENU =
            Target.the("Menu Home")
                    .locatedBy("//a[contains(@class,'nav-link') and normalize-space()='Home']");

    // Un elemento estable del catálogo para saber que ya cargó la página principal
    public static final Target CATEGORIES_PANEL =
            Target.the("Panel Categories")
                    .locatedBy("//div[@id='contcont']//div[contains(.,'CATEGORIES')]");

    // Producto por nombre (tu locator está bien)
    public static final Target PRODUCT_LINK_BY_NAME =
            Target.the("Producto por nombre")
                    .locatedBy("//a[@class='hrefch' and normalize-space()='{0}']");
}
