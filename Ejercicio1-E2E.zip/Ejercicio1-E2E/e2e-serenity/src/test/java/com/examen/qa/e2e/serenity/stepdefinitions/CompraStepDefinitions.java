package com.examen.qa.e2e.serenity.stepdefinitions;

import com.examen.qa.e2e.serenity.models.CompraData;
import com.examen.qa.e2e.serenity.tasks.*;
import io.cucumber.java.Before;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Entonces;
import io.cucumber.datatable.DataTable;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

import java.util.List;
import java.util.Map;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.containsString;
import net.serenitybdd.screenplay.questions.page.TheWebPage;

public class CompraStepDefinitions {

    @Before
    public void setUp() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Dado("que el usuario abre la pagina de Demoblaze")
    public void abrir_demoblaze() {
        Actor usuario = OnStage.theActorCalled("Usuario");
        usuario.wasAbleTo(AbrirHome.demoblaze());
    }

    @Cuando("agrega el producto {string} al carrito")
    public void agrega_producto(String producto) {
        OnStage.theActorInTheSpotlight().attemptsTo(AgregarProductoAlCarrito.llamado(producto));
    }

    @Cuando("visualiza el carrito")
    public void visualiza_carrito() {
        OnStage.theActorInTheSpotlight().attemptsTo(IrAlCarrito.ahora());
    }

    @Cuando("completa el formulario de compra con:")
    public void completa_formulario(DataTable table) {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        Map<String, String> r = rows.get(0);

        CompraData data = new CompraData(
                r.get("name"),
                r.get("country"),
                r.get("city"),
                r.get("card"),
                r.get("month"),
                r.get("year")
        );

        OnStage.theActorInTheSpotlight().attemptsTo(CompletarCompra.con(data));
    }

    @Entonces("la compra se finaliza correctamente")
    public void compra_ok() {
        OnStage.theActorInTheSpotlight().should(
                seeThat(TheWebPage.title(), containsString("STORE"))
        );
    }
}
