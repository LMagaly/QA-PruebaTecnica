package com.examen.qa.e2e.serenity.models;

public class CompraData {
    public final String name;
    public final String country;
    public final String city;
    public final String card;
    public final String month;
    public final String year;

    public CompraData(String name, String country, String city, String card, String month, String year) {
        this.name = name;
        this.country = country;
        this.city = city;
        this.card = card;
        this.month = month;
        this.year = year;
    }
}
