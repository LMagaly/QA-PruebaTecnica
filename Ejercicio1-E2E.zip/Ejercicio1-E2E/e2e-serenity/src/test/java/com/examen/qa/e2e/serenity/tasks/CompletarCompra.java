package com.examen.qa.e2e.serenity.tasks;

import com.examen.qa.e2e.serenity.models.CompraData;
import com.examen.qa.e2e.serenity.userinterface.CartPageUI;
import com.examen.qa.e2e.serenity.userinterface.PlaceOrderModalUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.*;

import net.serenitybdd.screenplay.waits.WaitUntil;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class CompletarCompra implements Task {

    private final CompraData data;

    public CompletarCompra(CompraData data) {
        this.data = data;
    }

    public static CompletarCompra con(CompraData data) {
        return Tasks.instrumented(CompletarCompra.class, data);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(CartPageUI.PLACE_ORDER),
                WaitUntil.the(PlaceOrderModalUI.NAME, isVisible()).forNoMoreThan(10).seconds(),

                Enter.theValue(data.name).into(PlaceOrderModalUI.NAME),
                Enter.theValue(data.country).into(PlaceOrderModalUI.COUNTRY),
                Enter.theValue(data.city).into(PlaceOrderModalUI.CITY),
                Enter.theValue(data.card).into(PlaceOrderModalUI.CARD),
                Enter.theValue(data.month).into(PlaceOrderModalUI.MONTH),
                Enter.theValue(data.year).into(PlaceOrderModalUI.YEAR),

                Click.on(PlaceOrderModalUI.PURCHASE),
                WaitUntil.the(PlaceOrderModalUI.SUCCESS_TITLE, isVisible()).forNoMoreThan(10).seconds(),
                Click.on(PlaceOrderModalUI.SUCCESS_OK)
        );
    }
}
