package com.examen.qa.e2e.serenity.userinterface;

import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.pages.PageObject;

@DefaultUrl("https://www.demoblaze.com/")
public class HomePage extends PageObject {
}
