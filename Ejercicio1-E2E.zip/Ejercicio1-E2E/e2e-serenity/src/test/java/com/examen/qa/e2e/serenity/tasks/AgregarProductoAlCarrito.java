package com.examen.qa.e2e.serenity.tasks;

import com.examen.qa.e2e.serenity.userinterface.HomePageUI;
import com.examen.qa.e2e.serenity.userinterface.ProductPageUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class AgregarProductoAlCarrito implements Task {

    private static final String HOME_URL = "https://www.demoblaze.com/index.html";
    private final String producto;

    public AgregarProductoAlCarrito(String producto) {
        this.producto = producto;
    }

    public static AgregarProductoAlCarrito llamado(String producto) {
        return Tasks.instrumented(AgregarProductoAlCarrito.class, producto);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {

        WebDriver driver = BrowseTheWeb.as(actor).getDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // ✅ Asegura que estás en Home y que el catálogo cargó
        driver.get(HOME_URL);
        actor.attemptsTo(
                WaitUntil.the(HomePageUI.CATEGORIES_PANEL, isVisible()).forNoMoreThan(10).seconds()
        );

        // ✅ Entra al producto por nombre
        actor.attemptsTo(
                WaitUntil.the(HomePageUI.PRODUCT_LINK_BY_NAME.of(producto), isVisible()).forNoMoreThan(10).seconds(),
                Click.on(HomePageUI.PRODUCT_LINK_BY_NAME.of(producto))
        );

        // ✅ Click Add to cart
        actor.attemptsTo(
                WaitUntil.the(ProductPageUI.ADD_TO_CART, isVisible()).forNoMoreThan(10).seconds(),
                Click.on(ProductPageUI.ADD_TO_CART)
        );

        // ✅ Alert: si aparece lo aceptamos; si se autocierra, NO fallamos
        try {
            wait.until(ExpectedConditions.alertIsPresent());
            driver.switchTo().alert().accept();
        } catch (TimeoutException ignored) {
            // El alert a veces se autocierra o no aparece a tiempo -> seguimos
        }

        // ✅ Volver SIEMPRE a Home (por URL) para poder seleccionar el siguiente producto
        driver.get(HOME_URL);
        actor.attemptsTo(
                WaitUntil.the(HomePageUI.CATEGORIES_PANEL, isVisible()).forNoMoreThan(10).seconds()
        );
    }
}
