package com.examen.qa.e2e.serenity.runners;

import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources/features/flujo_compra/compra_e2e.feature",
        glue = "com.examen.qa.e2e.serenity.stepdefinitions",
        tags = "@compra",
        plugin = {
                "pretty",
                "json:target/cucumber/cucumber.json"
        }
)
public class E2ECompraRunnerTest { }
