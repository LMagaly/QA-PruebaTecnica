package com.examen.qa.e2e.serenity.userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class CartPageUI {
    public static final Target CART_MENU =
            Target.the("Menu Cart")
                    .locatedBy("//a[@id='cartur']");

    public static final Target PLACE_ORDER =
            Target.the("Boton Place Order")
                    .locatedBy("//button[contains(.,'Place Order')]");
}
