package com.examen.qa.e2e.serenity.userinterface;

import net.serenitybdd.screenplay.targets.Target;

public class PlaceOrderModalUI {
    public static final Target NAME = Target.the("Name").locatedBy("#name");
    public static final Target COUNTRY = Target.the("Country").locatedBy("#country");
    public static final Target CITY = Target.the("City").locatedBy("#city");
    public static final Target CARD = Target.the("Credit card").locatedBy("#card");
    public static final Target MONTH = Target.the("Month").locatedBy("#month");
    public static final Target YEAR = Target.the("Year").locatedBy("#year");

    public static final Target PURCHASE = Target.the("Purchase").locatedBy("//button[contains(.,'Purchase')]");
    public static final Target SUCCESS_OK = Target.the("OK success").locatedBy("//button[contains(.,'OK')]");
    public static final Target SUCCESS_TITLE = Target.the("Success title").locatedBy("//h2[contains(.,'Thank you')]");
}
