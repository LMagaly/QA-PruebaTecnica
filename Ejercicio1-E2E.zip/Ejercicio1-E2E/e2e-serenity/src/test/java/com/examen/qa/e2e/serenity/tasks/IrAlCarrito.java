package com.examen.qa.e2e.serenity.tasks;

import com.examen.qa.e2e.serenity.userinterface.CartPageUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class IrAlCarrito implements Task {

    public static IrAlCarrito ahora() {
        return Tasks.instrumented(IrAlCarrito.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(CartPageUI.CART_MENU));
    }
}
